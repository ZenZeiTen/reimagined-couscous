---
name: Security vulnerability report
about: Report a security issue (use GitHub private reporting for sensitive disclosures)
title: "[SECURITY] "
labels: security
assignees: ''
---

**Note**: For sensitive vulnerabilities, use GitHub's private vulnerability reporting feature instead of this public form.

**Description**
A clear description of the vulnerability.

**Steps to reproduce**

**SHA-256 of lang-forge/SKILL.md you are using**

**Is this a tampering issue or a design flaw?**

**Suggested fix (optional)**
